public class MensajeExeption extends Exception{
    public MensajeExeption() {
        super();
    }

    public MensajeExeption(String message) {
        super(message);
    }
}
