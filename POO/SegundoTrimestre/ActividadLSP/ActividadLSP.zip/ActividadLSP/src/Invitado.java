public class Invitado extends Persona{
    public Invitado(String nombre, String apellido) {
        super(nombre, apellido);
    }
}
