package com.politecnicomalaga.calculadora;

public class Multiplicacion {
    public Multiplicacion() {
    }

    public int Multiplicar(int a, int b){
        return a * b;
    }
}
