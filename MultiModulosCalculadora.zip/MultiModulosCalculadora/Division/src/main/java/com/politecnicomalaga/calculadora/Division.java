package com.politecnicomalaga.calculadora;

public class Division {
    public Division() {
    }

    public double Dividir(double a, double b){
        double result = a/b;
        return result;
    }
}
