package com.politecnicomalaga.calculadora;

public class Suma {
    public Suma() {
    }

    public int Suma(int a, int b){
        return a + b;
    }
}
