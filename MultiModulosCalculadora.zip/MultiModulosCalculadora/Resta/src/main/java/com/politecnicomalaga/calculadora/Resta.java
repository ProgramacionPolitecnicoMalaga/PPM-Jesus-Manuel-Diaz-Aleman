package com.politecnicomalaga.calculadora;

public class Resta {
    public Resta() {
    }

    public int Resta(int a, int b){
        return a - b;
    }
}
